//============================================================================
// Name        : ABDUL WASAY
// Section     :  F
// Author      : FAST CS Department
// Version     :
// Copyright   : (c) Reserved
// Description : Basic 2D game of Rush Hour...
//============================================================================

#ifndef RushHour_CPP_
#define RushHour_CPP_
#include "util.h"
#include <iostream>
#include<iomanip>
#include<string>
#include<cmath> // for basic math functions such as cos, sin, sqrt
using namespace std;


                         int score=0;
                         float pool=0;
                        
                         
                         
//lOCATION OF PASSENGERS
 

int x1out=150;
int y1out=678;

int x2out=590;
int y2out=628;

int x3out=300;
int y3out=228;

int x4out=850;
int y4out=428;

int x5out=350;
int y5out=780;

int x6out=600;
int y6out=430;





//OPTION TO CHOOSE COLOR OF THE TAXI

int option;


//VARIABLES TO CONTROL SPACE KEY CONTROL 

int a=0;
int b=0;
int c=0;
int d=0;
int e=0;
int f=0;



//VARIABLES USED TO LINK GAME PAGE AND START MENU 

int n=0;
bool v;


//USED FOR MOVING CARS

bool flag = true;

//-----------------------------------------------------------------------------------------START MENU--------------------------------------------------------------------------------------// 
    
void start_menu()
{

//BACKGROUND COLORS
glClearColor(0,0,0.0,0); 
glClear (GL_COLOR_BUFFER_BIT);


//DISPLAYING THE START MENU
DrawString( 420, 710, "RUSH HOUR", colors[RED]);
DrawLine( 350 , 690 ,  650 , 690 , 5 , colors[GREEN] );
DrawString( 300, 400, "PRESS ENTER TO START THE GAME", colors[WHITE]);
DrawLine( 50 , 0 ,  50 , 900 , 10 , colors[GREEN] );
DrawLine( 950 , 0 ,  950 , 900 , 10 , colors[GREEN] );
	
}	

//-----------------------------------------------------------------------------------------CANVAS SIZE------------------------------------------------------------------------------------//
 
void SetCanvasSize(int width, int height) {
	glMatrixMode (GL_PROJECTION);
	glLoadIdentity();
	glOrtho(0, width, 0, height, -1, 1); // set the screen size to given width and height.
	glMatrixMode (GL_MODELVIEW);
	glLoadIdentity();
}

//INITIAL LOCATION OF TAXI
int xI = 0, yI = 800;


//LOCATION OF RANDOM CARS
int x2=50 , y2=50;
int x3=380 , y3=450;
int x4=100 , y4=250;



//------------------------------------------------------------------------------------RED CAR DISPLAY FUNCTION----------------------------------------------------------------------------//
void drawCarRed() {


	DrawSquare(xI, yI, 50, colors[RED]);
        DrawCircle(xI+5,yI,5,colors[WHITE]);
	DrawCircle(xI+40,yI,5,colors[WHITE]);
	DrawSquare(xI+30, yI+25, 10, colors[BLUE]);
	DrawSquare(xI+40, yI+25, 10, colors[BLUE]);
	DrawString( xI-6, yI+50, "TAXI", colors[YELLOW]);
	
	glutPostRedisplay();
	}
	
//-----------------------------------------------------------------------------------YELLOW CAR DISPLAY FUNCTION----------------------------------------------------------------------------//	
void drawCarYellow()
	
	{
	DrawSquare(xI, yI, 50, colors[YELLOW]);
	DrawCircle(xI+5,yI,5,colors[WHITE]);
	DrawCircle(xI+40,yI,5,colors[WHITE]);
	DrawSquare(xI+30, yI+25, 10, colors[BLUE]);
	DrawSquare(xI+40, yI+25, 10, colors[BLUE]);
	DrawString( xI-6, yI+50, "TAXI", colors[YELLOW]);
	
	glutPostRedisplay();
	}
	

//-----------------------------------------------------------------------------------FUNCTIONS TO DESIGN THE CARS---------------------------------------------------------------------------//



										void drawCar1() 
										{
											DrawSquare(x2, y2, 50, colors[BLUE]);
											DrawCircle(x2+5,y2,5,colors[WHITE]);
											DrawCircle(x2+40,y2,5,colors[WHITE]);
											DrawSquare(x2+30, y2+25, 10, colors[WHITE]);
											DrawSquare(x2+40, y2+25, 10, colors[WHITE]);
											
											glutPostRedisplay();
										}

										void drawCar2() 
										{
											DrawSquare(x3, y3, 50, colors[BLUE]);
											DrawCircle(x3+5,y3,5,colors[WHITE]);
											DrawCircle(x3+40,y3,5,colors[WHITE]);
											DrawSquare(x3+30, y3+25, 10, colors[WHITE]);
											DrawSquare(x3+40, y3+25, 10, colors[WHITE]);
																																	
											glutPostRedisplay();
										}

										void drawCar3() {
											DrawSquare(x4, y4, 50, colors[BLUE]);
											DrawCircle(x4+5,y4,5,colors[WHITE]);
											DrawCircle(x4+40,y4,5,colors[WHITE]);
											DrawSquare(x4+30, y4+25, 10, colors[WHITE]);
											DrawSquare(x4+40, y4+25, 10, colors[WHITE]);
																						
											glutPostRedisplay();
										}



//------------------------------------------------------------------------------MOVING CAR FUNCTIONS------------------------------------------------------------------------------------//

									void moveCar1() 
									{
										
										 if (x2 > 10 && flag)
										 {
										          x2 -= 10;
											  cout << "going left";
											
											        if(x2 < 100)
												
												    flag = false;

										 }
										 
										 else if (x2 < 500 && !flag)
										 {
											  cout << "go right";
											  x2 += 10;
											  
											       if (x2 > 450)
												
												    flag = true;
										 }
									}


									void moveCar2() 
									{
										
										if (x3 > 380 && flag) 
										{
											    x3 -= 10;
											    cout << "going left";
											
											        if(x3 < 380)
												
												    flag = false;

										}
										else if (x3 < 700 && !flag)
									        {
											cout << "go right";
											x3 += 10;
											
											        if (x3 > 700)
												
												    flag = true;
										}
									}

									void moveCar3() 
									{
										
										if (y4 > 250 && flag) 
										{
											    y4 -= 10;
											    cout << "going up";
											
											        if(y4 < 250)
												
												    flag = false;
										}
										else if (y4 < 550 && !flag) 
										{
										    	cout << "go right";
											y4 += 10;
											
											        if (y4 > 550)
												
												    flag = true;
										}
									}


//------------------------------------------------------------------------------------MAIN GAME DISPLAY FUNCTION-----------------------------------------------------------------------//

void GameDisplay()
{
	
if (n==1 )
{
	
        //BACKGROUND COLORS
	glClearColor(0,0,0.0,0); 
	glClear (GL_COLOR_BUFFER_BIT); //Update the colors



	//Display TOP BAR
	DrawString( 50, 810, "Score="+Num2Str(score), colors[RED]);		
	DrawString( 250, 810, "Timer:"+Num2Str(pool), colors[RED]);		
	DrawString( 700, 810, "Total Time = 3 Minutes", colors[YELLOW]);
        DrawLine( 0 , 800 ,  1100 , 800 , 0.5 , colors[RED] );
     
     
     
     
//--------------------------------------------------------------------------------------DISPLAYING THE PASSENGERS-----------------------------------------------------------------------//



//Passenger 1   	
        	
        	DrawCircle(x1out,y1out,8,colors[ORANGE]);
        	DrawCircle(x1out-3.5,y1out,2,colors[BLACK]);
        	DrawCircle(x1out+3.5,y1out,2,colors[BLACK]);
        	DrawSquare(x1out-10,y1out-28,21,colors[ORANGE]);
        	
        	if(a==1)	
               {
                       DrawSquare(650,50,50,colors[GREEN]);
               }

               if(a==2)	
               {
			DrawCircle(x1out,y1out,8,colors[RED]);
			DrawCircle(x1out-3.5,y1out,2,colors[BLACK]);
			DrawCircle(x1out+3.5,y1out,2,colors[BLACK]);        	
			DrawSquare(x1out-10,y1out-28,21,colors[RED]);
        	}
            
//Passenger 2
            
               DrawCircle(x2out,y2out,8,colors[ORANGE]);                                     	       DrawCircle(x2out-3.5,y2out,2,colors[BLACK]);
		DrawCircle(x2out+3.5,y2out,2,colors[BLACK]);
              	DrawSquare(x2out-10,y2out-28,21,colors[ORANGE]); 	
        	
        	if(b==1)	
		{
		        DrawSquare(750,50,50,colors[GREEN]);
		}

               if(b==2)	
               {

		        DrawCircle(x2out,y2out,8,colors[RED]);
			DrawCircle(x2out-3.5,y2out,2,colors[BLACK]);
			DrawCircle(x2out+3.5,y2out,2,colors[BLACK]);
			DrawSquare(x2out-10,y2out-28,21,colors[RED]);
        	}
        	
//Passenger 3
            
                DrawCircle(x3out,y3out,8,colors[ORANGE]);
                DrawCircle(x3out-3.5,y3out,2,colors[BLACK]);
        	 DrawCircle(x3out+3.5,y3out,2,colors[BLACK]);
        	 DrawSquare(x3out-10,y3out-28,21,colors[ORANGE]);
        	 
        	 if(c==1)	
		 {
		          DrawSquare(850,750,50,colors[GREEN]);
		 }

		if(c==2)	
		{
		           DrawCircle(x3out,y3out,8,colors[RED]);
        	           DrawCircle(x3out-3.5,y3out,2,colors[BLACK]);
        	           DrawCircle(x3out+3.5,y3out,2,colors[BLACK]);       	
        	           DrawSquare(x3out-10,y3out-28,21,colors[RED]);
        	}
        	
//Passenger 4
            
                DrawCircle(x4out,y4out,8,colors[ORANGE]);
                DrawCircle(x4out-3.5,y4out,2,colors[BLACK]);
        	 DrawCircle(x4out+3.5,y4out,2,colors[BLACK]);
        	 DrawSquare(x4out-10,y4out-28,21,colors[ORANGE]);
        	
        	if(d==1)	
		{
		           DrawSquare(100,200,50,colors[GREEN]);
		}

		if(d==2)	
		{
				DrawCircle(x4out,y4out,8,colors[RED]);
				DrawCircle(x4out-3.5,y4out,2,colors[BLACK]);
				DrawCircle(x4out+3.5,y4out,2,colors[BLACK]);
			      	DrawSquare(x4out-10,y4out-28,21,colors[RED]);
		}
	
	
//Passenger 5
            
                DrawCircle(x5out,y5out,8,colors[ORANGE]);
                DrawCircle(x5out-3.5,y5out,2,colors[BLACK]);
        	 DrawCircle(x5out+3.5,y5out,2,colors[BLACK]);
        	 DrawSquare(x5out-10,y5out-28,21,colors[ORANGE]);
        	
        	if(e==1)	
		{
		           DrawSquare(900,300,50,colors[GREEN]);
		}

		if(e==2)	
		{
				DrawCircle(x5out,y5out,8,colors[RED]);
				DrawCircle(x5out-3.5,y5out,2,colors[BLACK]);
				DrawCircle(x5out+3.5,y5out,2,colors[BLACK]);
			      	DrawSquare(x5out-10,y5out-28,21,colors[RED]);
		}
		
//Passenger 6
            
                DrawCircle(x6out,y6out,8,colors[ORANGE]);
                DrawCircle(x6out-3.5,y6out,2,colors[BLACK]);
        	 DrawCircle(x6out+3.5,y6out,2,colors[BLACK]);
        	 DrawSquare(x6out-10,y6out-28,21,colors[ORANGE]);
        	
        	if(f==1)	
		{
		           DrawSquare(700,200,50,colors[GREEN]);
		}

		if(f==2)	
		{
				DrawCircle(x6out,y6out,8,colors[RED]);
				DrawCircle(x6out-3.5,y6out,2,colors[BLACK]);
				DrawCircle(x6out+3.5,y6out,2,colors[BLACK]);
			      	DrawSquare(x6out-10,y6out-28,21,colors[RED]);
		}

	

	
	

//--------------------------------------------------------------------------------------DISPLAYING THE TREES-----------------------------------------------------------------------//

	
	//TREE 1
	
	DrawLine( 730 , 150 ,  730 , 180 , 15 , colors[BROWN] );
	DrawCircle(740,175,10,colors[GREEN]);
	DrawCircle(730,180,10,colors[GREEN]);
	DrawCircle(720,175,10,colors[GREEN]);
	
	//TREE 2
	
	DrawLine( 730 , 400 ,  730 , 430 , 15 , colors[BROWN] );
	DrawCircle(740,425,10,colors[GREEN]);
	DrawCircle(730,430,10,colors[GREEN]);
	DrawCircle(720,425,10,colors[GREEN]);
	
	//TREE 3
	
	DrawLine( 730 , 750 ,  730 , 780 , 15 , colors[BROWN] );
	DrawCircle(740,775,10,colors[GREEN]);
	DrawCircle(730,780,10,colors[GREEN]);
	DrawCircle(720,775,10,colors[GREEN]);
	
	//TREE 4
		
	DrawLine( 230 , 200 ,  230 , 230 , 15 , colors[BROWN] );
	DrawCircle(240,225,10,colors[GREEN]);
	DrawCircle(230,230,10,colors[GREEN]);
	DrawCircle(220,225,10,colors[GREEN]);
	
	
	
	
//-------------------------------------------------------------------------------DISPLAYING THWE BUILDINGS -------------------------------------------------------------------------//
	
	DrawSquare(550,550,50,colors[BEIGE]);
	DrawSquare(600,550,50,colors[BEIGE]);
	DrawSquare(650,550,50,colors[BEIGE]);
	DrawSquare(700,550,50,colors[BEIGE]);
	DrawSquare(750,550,50,colors[BEIGE]);
	DrawSquare(800,550,50,colors[BEIGE]);
	DrawSquare(850,550,50,colors[BEIGE]);
	
	DrawSquare(550,350,50,colors[BEIGE]);
	DrawSquare(600,350,50,colors[BEIGE]);
	DrawSquare(650,350,50,colors[BEIGE]);
	DrawSquare(700,350,50,colors[BEIGE]);
	DrawSquare(750,350,50,colors[BEIGE]);
	DrawSquare(800,350,50,colors[BEIGE]);
		
	DrawSquare(850,350,50,colors[BEIGE]);
	DrawSquare(850,300,50,colors[BEIGE]);
	DrawSquare(850,250,50,colors[BEIGE]);
	DrawSquare(850,200,50,colors[BEIGE]);
	DrawSquare(850,150,50,colors[BEIGE]);
	
	DrawSquare(850,600,50,colors[BEIGE]);
	DrawSquare(850,650,50,colors[BEIGE]);
	DrawSquare(850,700,50,colors[BEIGE]);
	
	DrawSquare(50,600,50,colors[BEIGE]);
	DrawSquare(100,600,50,colors[BEIGE]);
	DrawSquare(150,600,50,colors[BEIGE]);
	
	
	DrawSquare(300,700,50,colors[BEIGE]);
	DrawSquare(350,700,50,colors[BEIGE]);
	DrawSquare(400,700,50,colors[BEIGE]);
	
		
	DrawSquare(50,150,50,colors[BEIGE]);
	DrawSquare(100,150,50,colors[BEIGE]);
	DrawSquare(150,150,50,colors[BEIGE]);
	DrawSquare(200,150,50,colors[BEIGE]);
	DrawSquare(250,150,50,colors[BEIGE]);	
        DrawSquare(300,150,50,colors[BEIGE]);	
	DrawSquare(350,150,50,colors[BEIGE]);
	DrawSquare(400,150,50,colors[BEIGE]);
	DrawSquare(450,150,50,colors[BEIGE]);
	DrawSquare(500,150,50,colors[BEIGE]);
	DrawSquare(550,150,50,colors[BEIGE]);
	
	
	DrawSquare(700,650,50,colors[BEIGE]);
	DrawSquare(700,700,50,colors[BEIGE]);	
        
        	
        DrawSquare(250,700,50,colors[BEIGE]);
        DrawSquare(250,650,50,colors[BEIGE]);
        DrawSquare(250,600,50,colors[BEIGE]);
        DrawSquare(250,550,50,colors[BEIGE]);
        DrawSquare(250,500,50,colors[BEIGE]);
        DrawSquare(250,450,50,colors[BEIGE]);
        DrawSquare(250,400,50,colors[BEIGE]);
        DrawSquare(250,350,50,colors[BEIGE]);
        
        
        DrawSquare(600,0,50,colors[BEIGE]);
        DrawSquare(650,0,50,colors[BEIGE]);
        DrawSquare(700,50,50,colors[BEIGE]);
        DrawSquare(700,100,50,colors[BEIGE]);
        DrawSquare(700,0,50,colors[BEIGE]);
        DrawSquare(750,0,50,colors[BEIGE]);
        
        
//--------------------------------------------------------------------------------------BACKGROUND PATTERN---------------------------------------------------------------------------------//
        
       DrawLine( 50 , 0 ,  50 , 800 , 1 ,  colors[WHITE]  );
       DrawLine( 100 , 0 ,  100 , 800 , 1 , colors[WHITE] );
       DrawLine( 150 , 0 ,  150 , 800 , 1 , colors[WHITE] );
       DrawLine( 200 , 0 ,  200 , 800 , 1 , colors[WHITE] );
       DrawLine( 250 , 0 ,  250 , 800 , 1 , colors[WHITE] );
       DrawLine( 300 , 0 ,  300 , 800 , 1 , colors[WHITE] );
       DrawLine( 350 , 0 ,  350 , 800 , 1 , colors[WHITE] );
       DrawLine( 400 , 0 ,  400 , 800 , 1 , colors[WHITE] );
       DrawLine( 450 , 0 ,  450 , 800 , 1 , colors[WHITE] );
       DrawLine( 500 , 0 ,  500 , 800 , 1 , colors[WHITE] );
       DrawLine( 550 , 0 ,  550 , 800 , 1 , colors[WHITE] );
       DrawLine( 600 , 0 ,  600 , 800 , 1 , colors[WHITE] );
       DrawLine( 650 , 0 ,  650 , 800 , 1 , colors[WHITE] );
       DrawLine( 700 , 0 ,  700 , 800 , 1 , colors[WHITE] );
       DrawLine( 750 , 0 ,  750 , 800 , 1 , colors[WHITE] );
       DrawLine( 800 , 0 ,  800 , 800 , 1 , colors[WHITE] );
       DrawLine( 850 , 0 ,  850 , 800 , 1 , colors[WHITE] );
       DrawLine( 900 , 0 ,  900 , 800 , 1 , colors[WHITE] );
       DrawLine( 950 , 0 ,  950 , 800 , 1 , colors[WHITE] );
       DrawLine( 1000 ,0 ,  1000 , 800 , 1 , colors[WHITE]);
       
       
        
       
//--------------------------------------------------------------------------------------CONDITIONS FOR TREES---------------------------------------------------------------------------------//
    
    
    //TREE 1:
    
					       if (xI==740)
						{
						           if (yI>=150 && yI<=180)
							    {
							    xI+=10;
							    score=score-2;
							    }
						}
    
    
    
                                              if (xI==670)
	                                      {
	    						    if (yI>=150 && yI<=180)
		    					    {
							    xI-=10;
							    score=score-2;
					    		    }
					       }
    
    
    
                                              if (yI==180)
	                                      {
	                                                   if (xI>=670 && xI<=740)
		                                            {
							      yI+=10;
							      score=score-2;
							      }
	                                      }
       
       
   //TREE 2:
      
					       if (xI==740)
					       {
					                    if (yI>=750 && yI<=780)
						             {
							      xI+=10;
							      score=score-2;
						    	      }
					       }
				    
				    
				    
				               if (xI==670)
					       {
					                    if (yI>=750 && yI<=780)
						             {
						             xI-=10;
						             score=score-2;
					   		     }
					       }
				    
				    
				    
					       if (yI==780)
					       {
					                    if (xI>=670 && xI<=740)
					        	     {						  
						             yI+=10;
						             score=score-2;
						    	      }
					       }
				  
      
      
      
      
       
  //TREE 3:
  
					    if (xI==740)
					    {
						            if (yI>=400 && yI<=430)
							    {
							    xI+=10;
							    score=score-2;
							    }
					    }
					    
					    
					    if (xI==670)
					    {
						           if (yI>=400 && yI<=430)
							    {							  
							    xI-=10;
							    score=score-2;
							    }
					    }
					    
					    
					    
					    if (yI==430)
				            {
						            if (xI>=670 && xI<=740)
							    {
							    yI+=10;
							    score=score-2;
							    }
				            }
					  
  
  
    
       
//TREE 4:     
						if (xI==240)
						{
						             if (yI>=200 && yI<=230)
							      {							  
							      xI+=10;
							      score=score-2;
				           		      }
						}
					       
					       
					       
						if (xI==170)
						 {
						             if (yI>=200 && yI<=230)
							      {							  
							      xI-=10;
							      score=score-2;
							      }
						 }
					       
					       
					       
						if (yI==230)
						{
						            if (xI>=170 && xI<=240)
							     {							  
							     yI+=10;
							     score=score-2;
							     }
						}
					       
       
       
       
       
       
//---------------------------------------------------------------------CONDITIONS TO STOP TAXI FROM MOVING OVER BUILDINGS--------------------------------------------------------------------// 
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
       
if (yI==560)
	 {
	    if (xI>=10 && xI<=190)
		    {
		  

		    yI-=10;
		    		    }
	 }

if (yI==640)
	 {
	    if (xI>=10 && xI<=190)
		    {
		
                
    yI+=10;
		    
		    }
	 }
	 
	 
if (yI==510)
	 {
	     if ( xI>=510 && xI<=890 )    
	          {

	          yI-=10;
	          }
	 }
	 
if (yI==590)
	 {
	      if ( xI>=510 && xI<=890 )
	          {

	          yI+=10;
	          }
	 }
	 
	 
if (yI==660)
	  {
	  
	      if ( xI>=210 && xI<=440 )
	   
               {

	       yI-=10;
	       }
	  }
	 
if (yI==740)
	  {
	  
	      if ( xI>=210 && xI<=440 )
	 
	       {

	       yI+=10;
	       }
	  }
	 
	 
if (yI==310)
	  {
	      if ( xI>=510 && xI<=890 )
	      {

	       yI-=10;
      	      }
	  }
	 
if (yI==390)
	  {
	      if ( xI>=510 && xI<=890 )
	      {

	       yI+=10;
	      }
	 }
	 	 
if (yI==110)
	  {
	      if (xI>=10 && xI<=590 )
	 
	      {

	       yI-=10;
	      }
	 }
	 
	
if (yI==190)
	  {
	  
	       if (xI>=10 && xI<=590 ) 
	 
	       {
	       yI+=10;
	       }
	 }


	 
if (yI==110)
	  {
	  
               if (xI>=810 && xI<=890 ) 
	 
	       {
	       yI-=10;
	       }
	  }
	 
if (yI==740)
	  {
	  
               if (xI>=810 && xI<=890 ) 
	 
	       {
	       yI+=10;
	       }
	 }
	 
	 
if (yI==740)
	  {
	  
	        if (xI>=660 && xI<=740 ) 
	 
	       {
yI+=10;
	       }
	  }
	 
	 
	  if (yI==610)
	  {
	  
	   if (xI>=660 && xI<=740 ) 
	 
	   	      {
yI-=10;
	    }
	 }
	 
	 
	 if (yI==310)
	  {
	  
	   if (xI>=210 && xI<=290 ) 
	 
	    {
yI-=10;
	    }
	 }
	 
	//=========================================================================//
	 
	if (xI==10)
	{
	  if (yI>=110 && yI<=190)
	    {
xI-=10;
	    }
	    
	 }
	 
	
	if (xI==10)
	{
	  if (yI>=560 && yI<=630)
	    {
xI-=10;
	    }
	    
	 } 
	 
	 
	 if (xI==590)
	 {
	    if (yI>=110 && yI<=190)
	    {
xI+=10;                  
	    }
	    
	 } 
	 
	 	 if (xI==510)
	 {
	    if (yI>=310 && yI<=390)
	    {
xI-=10;                  
	    }
	    
	 } 
	 
	 
	  	 if (xI==810)
	 {
	    if (yI>=110 && yI<=300)
	    {
             xI-=10;                  
	    }
	    
	 } 
	 
	 
	   	 if (xI==890)
	 {
	    if (yI>=110 && yI<=390)
	    {
             xI+=10;                  
	    }
	    
	 } 
	 
	 	   	 if (xI==890)
	 {
	    if (yI>=510 && yI<=740)
	    {
             xI+=10;                  
	    }
	    
	 } 
	 
	 
	 	 	   	 if (xI==810)
	 {
	    if (yI>=510 && yI<=740)
	    {
             xI-=10;                  
	    }
	    
	 } 
	 
	 
	  	   	 if (xI==740)
	 {
	    if (yI>=610 && yI<=740)
	    {
             xI+=10;                  
	    }
	    
	 } 
	 
	 	  	   	 if (xI==660)
	 {
	    if (yI>=610 && yI<=740)
	    {
             xI-=10;                  
	    }
	    
	 } 
	 
	 
	 if (xI==510)
	 {
	    if (yI>=510 && yI<=590)
	    {
             xI-=10;                  
	    }
	    
	 }
	 
	 
	 	 	   	 if (xI==440)
	 {
	    if (yI>=660 && yI<=740)
	    {
             xI+=10;                  
	    }
	    
	 } 
	 
	 	   	 if (xI==290)
	 {
	    if (yI>=310 && yI<=740)
	    {
             xI+=10;                  
	    }
	    
	 } 
	 
	 if (xI==210)
	 {
	    if (yI>=310 && yI<=740)
	    {
             xI-=10;                  
	    }
	    
	 } 
	
	if (xI==190)
	 {
	    if (yI>=560 && yI<=640)
	    {
             xI+=10;                  
	    }
	    
	 }
	
	if (xI==660)
	 {
	    if (yI>=0 && yI<=140)
	    {
             xI-=10;                  
	    }
	    
	 }
	 
	 
	 if (xI==740)
	 {
	    if (yI>=0 && yI<=140)
	    {
             xI+=10;                  
	    }
	    
	 }
	 
	 
	 	 if (xI==790)
	 {
	    if (yI>=0 && yI<=40)
	    {
             xI+=10;                  
	    }
	    
	 }
	 
	 
	 	 if (xI==560)
	 {
	    if (yI>=0 && yI<=40)
	    {
             xI-=10;                  
	    }
	    
	 }
	 
	  if (yI==40)
	 {
	    if (xI>=560 && xI<=790)
	    {
             yI+=10;                  
	    }
	    
	 }
	 
	 
	   if (yI==140)
	 {
	    if (xI>=660 && xI<=740)
	    {
             yI+=10;                  
	    }
	    
	 }

	 
	 //===============CONDITIONS FOR BOUNDARY=============//
	 
	 if (xI<0)
	 {
	   if (yI<=1000)
	   {
            xI+=10;
	   }
	   
	  }
     
         if (xI>970)
	 {
	   if (yI<=1000)
	   {
            xI-=10;
	   }
	   
	  }

          if (yI<0)
	 {
	   if (xI<=1000)
	   {
            yI+=10;
	   }
	   
	  }
	
	if ( yI>750)
	 {
	   
            yI-=10;
	  }



//SWITCH OPEARATOR USED TO DECIDE COLOR OF TAXI

switch(option)
{
              case 1:
	                drawCarRed();
	                break;
              case 2:
                        drawCarYellow();
                        break;
}        	
	drawCar1();
	drawCar2();
	drawCar3();
	
	
	
	// Score deduction by hitting a car
	
	if(xI==x2 && yI==y2)
	{
	score=score-3;
	}
	      if(xI==x3 && yI==y3)
		{
		score=score-3;
		}
	               
			       if(xI==x4 && yI==y4)
				{
				score=score-3;
				}
	}
	
	
			       
	if (n==0  )
		{
		start_menu();
		glutPostRedisplay();
		}	
	
	if (pool>180)
        {
        exit(1);
        }
	
	glutSwapBuffers(); // do not modify this line..

}





void NonPrintableKeys(int key, int x, int y) {
	
	if (key== GLUT_KEY_LEFT )
	{
		xI -= 10;		
	} 
	
	else if (key== GLUT_KEY_RIGHT ) 
	{
		xI += 10;
	} 
	
	else if (key== GLUT_KEY_UP) 
	{
		yI  += 10;
	}

	else if (key== GLUT_KEY_DOWN) 
	{
		yI -= 10;
	}

	 
	glutPostRedisplay();

}



 
void PrintableKeys(unsigned char key, int x, int y) {
	if (key == 27)        // Escape key ASCII 
	{
		exit(1);      // exit the program when escape key is pressed.
	}

	if (key == 13)
	{
		n=n+1;
	}
	
		
//---------------------------------------------------------------------------------CONDITIONS TO PICK UP PASSENGER----------------------------------------------------------------//		
	
	
//PASSENGER 1
	
		if ((xI>=x1out-50 && xI<=x1out+50) && (yI<=y1out+50 && yI>=y1out-50) )
		{
			if (key == 32)
			{
			x1out=1000;
			y1out=1000;
			
			a=a+1;
			
			
			}
			}
			
		else if (xI==650 && yI==50 && a==1) 
		{
			if (key == 32)
			{
			x1out=670;
                       y1out=75;
			
			a=a+1;
			score=score+10;
			
			}
		}	
	
	
	
//PASSENGER 2
	
		if ((xI>=x2out-50 && xI<=x2out+50) && (yI<=y2out+50 && yI>=y2out-50) )
		{
			if (key == 32)
			{
			x2out=1000;
			y2out=1000;
			
			b=b+1;
			
			}
			}
			
	
		else if (xI==750 && yI==50 && b==1) 
		{
			if (key == 32)
			{
			x2out=770;
                       y2out=75;
			
			b=b+1;
			score=score+10;
					
			}
		}                                   	
//PASSENGER 3
	
	        if ((xI>=x3out-50 && xI<=x3out+50) && (yI<=y3out+50 && yI>=y3out-50) )
                {
                       if (key == 32)
	               {
	               x3out=1000;
	               y3out=1000;
	
	               c=c+1;
	
                      }
	        }
	
		else if (xI==850 && yI==750 && c==1) 
		{
			if (key == 32)
			{
			x3out=870;
                       y3out=775;
			
			c=c+1;
			score=score+10;
			
			
			}
		}
//PASSENGER 4
	
	
	if ((xI>=x4out-50 && xI<=x4out+50) && (yI<=y4out+50 && yI>=y4out-50) )
        {
	              if (key == 32)
	              {
	              x4out=1000;
	              y4out=1000;
	
                      d=d+1;
	
	              }
	}
	
	else if (xI==100 && yI==200 && d==1) 
	{
			if (key == 32)
			{
			x4out=120;
                       y4out=225;
			
			d=d+1;
			score=score+10;
			
			
			}
	}
		
	



//PASSENGER 5
	
	
	if ((xI>=x5out-50 && xI<=x5out+50) && (yI<=y5out+50 && yI>=y5out-50) )
        {
	              if (key == 32)
	              {
	              x5out=1000;
	              y5out=1000;
	
                      e=e+1;
	
	              }
	}
	
	else if (xI==900 && yI==300 && e==1) 
	{
			if (key == 32)
			{
			x5out=920;
                       y5out=325;
			
			e=e+1;
			score=score+10;
			
			
			}
		}
		
//PASSENGER 6
	
	
	if ((xI>=x6out-50 && xI<=x6out+50) && (yI<=y6out+50 && yI>=y6out-50) )
        {
	              if (key == 32)
	              {
	              x6out=1000;
	              y6out=1000;
	
                      f=f+1;
	
	              }
	}
	
	else if (xI==700 && yI==200 && f==1) 
	{
			if (key == 32)
			{
			x5out=720;
                       y5out=225;
			
			f=f+1;
			score=score+10;
			
			
			}
		}
		
	glutPostRedisplay();

}

void Timer(int m) {

	
	moveCar1();
        moveCar2();
        moveCar3();
        
        pool=pool+0.1;
        
        
        
	glutTimerFunc(100, Timer, 0);
	
}


int main(int argc, char*argv[]) 
{

	int width = 1020, height = 840; // i have set my window size to be 800 x 600
	
	
	
        cout<<"\n\n\n=================================================================================================================================================================\n\n\n"<<endl;	
	cout<<"                                                     CHOOSE THE COLOR OF THE TAXI: ";
	cout<<"\n                                                      1) RED"<<endl;
	cout<<"                                                      2) YELLOW"<<endl;
	cin>>option; 
	
	string name;
	cout<<"Enter your name:  ";
	cin>>name;
		
	InitRandomizer(); // seed the random number generator...
	glutInit(&argc, argv); // initialize the graphics library...
	glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA); // we will be using color display mode
	glutInitWindowPosition(50, 50); // set the initial position of our window
	glutInitWindowSize(width, height); // set the size of our window
	glutCreateWindow("Hour Rush by Naveed Ahmad"); // set the title of our game window
	SetCanvasSize(width, height); // set the number of pixels...



	glutDisplayFunc(GameDisplay); // tell library which function to call for drawing Canvas.
	glutSpecialFunc(NonPrintableKeys); // tell library which function to call for non-printable ASCII characters
	glutKeyboardFunc(PrintableKeys); 
	glutTimerFunc(1000.0, Timer, 0);

	glutMainLoop();
	return 1;
}
#endif /* RushHour_CPP_ */
